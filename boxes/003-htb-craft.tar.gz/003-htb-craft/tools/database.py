import pymysql
from craft_api import settings

conn = pymysql.connect(host=settings.MYSQL_DATABASE_HOST,
    user=settings.MYSQL_DATABASE_USER,
    password=settings.MYSQL_DATABASE_PASSWORD,
    db=settings.MYSQL_DATABASE_DB,
    cursorclass=pymysql.cursors.DictCursor)

try:
    with conn.cursor() as cursor:
        while True:
            sql = input(" >> ")
            if sql == "exit":
                break

            cursor.execute(sql)
            for row in cursor.fetchall():
                print(row)
finally:
    conn.close()
